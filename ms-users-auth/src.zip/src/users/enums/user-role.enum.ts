export enum UserRole {
  CLIENTE = 'cliente',
  EMPRENDEDOR = 'emprendedor',
  ORGANIZADOR = 'organizador',
}
